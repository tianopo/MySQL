UPDATE aluno SET curso_id = 2 WHERE nome LIKE 'A%';
UPDATE aluno
SET curso_id = 2
WHERE data_nascimento >= '1998-01-01';
select * from aluno;